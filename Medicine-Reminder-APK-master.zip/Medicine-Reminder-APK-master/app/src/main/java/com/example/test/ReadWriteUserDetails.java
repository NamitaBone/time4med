package com.example.test;

public class ReadWriteUserDetails {

    public String dob, gender,mobile;

    public ReadWriteUserDetails(String textDOB, String textGender, String textMobile){
        this.dob = textDOB;
        this.gender = textGender;
        this.mobile = textMobile;
    }
}
